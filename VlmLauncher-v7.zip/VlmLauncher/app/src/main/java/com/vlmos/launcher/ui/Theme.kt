package com.vlmos.launcher.ui

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shadow
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.unit.dp

/** Paleta neon do VLM OS. */
object Neon {
    val Bg = Color(0xFF05070D)
    val Bg2 = Color(0xFF0A1020)
    val Cyan = Color(0xFF00E5FF)
    val Violet = Color(0xFF7C4DFF)
    val Text = Color(0xFFE6F7FF)
    val Dim = Color(0xFF7FA3B5)
}

val Mono: FontFamily = FontFamily.Monospace

/** Sombra colorida que dá o efeito de brilho neon no texto. */
fun glow(color: Color, radius: Float = 24f) =
    Shadow(color = color.copy(alpha = 0.85f), offset = Offset.Zero, blurRadius = radius)

@Composable
fun LauncherTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = Neon.Cyan,
            onPrimary = Neon.Bg,
            background = Neon.Bg,
            surface = Neon.Bg2,
            onSurface = Neon.Text,
        ),
        content = content,
    )
}

/** Fundo: degradê escuro, grade tênue e um halo ciano atrás do relógio. */
fun Modifier.techBackground(): Modifier = drawBehind {
    drawRect(Brush.verticalGradient(listOf(Neon.Bg, Neon.Bg2, Neon.Bg)))

    val gridColor = Neon.Cyan.copy(alpha = 0.05f)
    val step = 48.dp.toPx()
    var x = 0f
    while (x < size.width) {
        drawLine(gridColor, Offset(x, 0f), Offset(x, size.height), 1f)
        x += step
    }
    var y = 0f
    while (y < size.height) {
        drawLine(gridColor, Offset(0f, y), Offset(size.width, y), 1f)
        y += step
    }

    drawRect(
        Brush.radialGradient(
            colors = listOf(Neon.Cyan.copy(alpha = 0.12f), Color.Transparent),
            center = Offset(size.width / 2f, size.height * 0.38f),
            radius = size.width * 0.8f,
        ),
    )
}
