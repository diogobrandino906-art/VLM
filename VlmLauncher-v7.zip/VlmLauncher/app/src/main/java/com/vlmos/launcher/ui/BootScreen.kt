package com.vlmos.launcher.ui

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay

/** Guarda se a abertura já rodou neste processo (não repete a cada toque no Home). */
object BootState {
    @Volatile
    var done: Boolean = false
}

private const val BOOT_TITLE = "SISTEMA OPERACIONAL VLM"

/** Abertura: o título é "digitado" com brilho neon e uma barra de progresso. Toque para pular. */
@Composable
fun BootScreen(onFinished: () -> Unit) {
    var shown by remember { mutableIntStateOf(0) }
    var cursorOn by remember { mutableStateOf(true) }
    val progress = remember { Animatable(0f) }

    LaunchedEffect(Unit) {
        for (i in 1..BOOT_TITLE.length) {
            shown = i
            delay(45)
        }
        progress.animateTo(1f, tween(durationMillis = 600, easing = LinearEasing))
        delay(250)
        onFinished()
    }
    LaunchedEffect(Unit) {
        while (true) {
            delay(350)
            cursorOn = !cursorOn
        }
    }

    val titleStyle = TextStyle(
        fontFamily = Mono,
        fontSize = 18.sp,
        letterSpacing = 1.sp,
        fontWeight = FontWeight.Bold,
    )

    Box(
        Modifier
            .fillMaxSize()
            .techBackground()
            .clickable(interactionSource = remember { MutableInteractionSource() }, indication = null) {
                onFinished()
            },
        contentAlignment = Alignment.Center,
    ) {
        Column(Modifier.padding(horizontal = 24.dp)) {
            Box {
                // Texto invisível reserva o espaço do título inteiro, para não "pular" enquanto digita.
                Text("$BOOT_TITLE█", style = titleStyle, color = Color.Transparent)
                Text(
                    BOOT_TITLE.take(shown) + if (cursorOn) "█" else "",
                    style = titleStyle.copy(shadow = glow(Neon.Cyan)),
                    color = Neon.Cyan,
                )
            }
            Spacer(Modifier.height(18.dp))
            Text(
                "INICIALIZANDO…",
                fontFamily = Mono,
                fontSize = 11.sp,
                letterSpacing = 3.sp,
                color = Neon.Dim,
            )
            Spacer(Modifier.height(8.dp))
            Box(Modifier.width(270.dp).height(2.dp).background(Neon.Cyan.copy(alpha = 0.15f))) {
                Box(
                    Modifier
                        .fillMaxWidth(progress.value)
                        .fillMaxHeight()
                        .background(Neon.Cyan),
                )
            }
        }
    }
}
