package com.vlmos.launcher

import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.setValue
import com.vlmos.launcher.ui.LauncherScreen
import com.vlmos.launcher.ui.LauncherTheme

class MainActivity : ComponentActivity() {

    // Muda a cada volta ao launcher: recarrega a lista de apps.
    private var resumeTick by mutableIntStateOf(0)

    // Muda quando o Home é apertado com o launcher já aberto: fecha a gaveta.
    private var homeTick by mutableIntStateOf(0)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        // Fundo sempre escuro: força ícones claros na barra de status e de navegação.
        enableEdgeToEdge(
            statusBarStyle = SystemBarStyle.dark(Color.TRANSPARENT),
            navigationBarStyle = SystemBarStyle.dark(Color.TRANSPARENT),
        )
        setContent {
            LauncherTheme {
                LauncherScreen(resumeTick, homeTick)
            }
        }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        homeTick++
    }

    override fun onResume() {
        super.onResume()
        resumeTick++
    }
}
