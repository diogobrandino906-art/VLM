package com.vlmos.launcher.ui

import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioTrack
import kotlin.math.PI
import kotlin.math.exp
import kotlin.math.min
import kotlin.math.sin

/**
 * Som de abertura gerado por código (sem arquivo de áudio, sem internet):
 * uma subida eletrônica (~0,45 s) seguida de um "ding" duplo que decai (~0,5 s).
 */
object BootSound {
    private const val RATE = 22050
    private const val SWEEP_SEC = 0.45
    private const val CHIME_SEC = 0.5

    /** Duração total em milissegundos. */
    const val DURATION_MS: Long = ((SWEEP_SEC + CHIME_SEC) * 1000).toLong()

    private fun buildPcm(): ShortArray {
        val sweepN = (RATE * SWEEP_SEC).toInt()
        val chimeN = (RATE * CHIME_SEC).toInt()
        val out = ShortArray(sweepN + chimeN)
        val max = Short.MAX_VALUE.toDouble()

        // Subida: frequência 200 Hz -> 900 Hz, com entrada suave.
        var phase = 0.0
        for (i in 0 until sweepN) {
            val t = i.toDouble() / sweepN
            val freq = 200.0 + 700.0 * t * t
            phase += 2.0 * PI * freq / RATE
            val env = min(1.0, t * 10.0) * (0.4 + 0.6 * t)
            out[i] = (sin(phase) * env * 0.35 * max).toInt().toShort()
        }

        // "Ding": duas notas (E6 e B6) com decaimento exponencial.
        for (j in 0 until chimeN) {
            val t = j.toDouble() / RATE
            val env = exp(-t * 7.0)
            val v = sin(2.0 * PI * 1318.5 * t) * 0.6 + sin(2.0 * PI * 1975.5 * t) * 0.4
            out[sweepN + j] = (v * env * 0.45 * max).toInt().toShort()
        }
        return out
    }

    /** Toca o som. Devolve o AudioTrack (para parar/liberar depois) ou null se falhar. */
    fun start(): AudioTrack? = try {
        val pcm = buildPcm()
        val track = AudioTrack.Builder()
            .setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_MEDIA)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                    .build(),
            )
            .setAudioFormat(
                AudioFormat.Builder()
                    .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                    .setSampleRate(RATE)
                    .setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
                    .build(),
            )
            .setBufferSizeInBytes(pcm.size * 2)
            .setTransferMode(AudioTrack.MODE_STATIC)
            .build()
        track.write(pcm, 0, pcm.size)
        track.play()
        track
    } catch (e: Exception) {
        null
    }
}
