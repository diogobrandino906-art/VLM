package com.vlmos.launcher.ui

import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.LocalContentColor
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import com.vlmos.launcher.AppInfo
import com.vlmos.launcher.AppRepository
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/**
 * Orquestra as três camadas: tela inicial (relógio), gaveta de apps (desliza por cima)
 * e abertura (só na primeira vez que o processo inicia).
 *
 * @param resumeTick muda a cada volta ao launcher: recarrega a lista de apps.
 * @param homeTick muda quando o botão Home é apertado: fecha a gaveta.
 */
@Composable
fun LauncherScreen(resumeTick: Int, homeTick: Int) {
    val ctx = LocalContext.current
    var apps by remember { mutableStateOf<List<AppInfo>>(AppRepository.cached()) }
    var query by remember { mutableStateOf("") }
    var drawer by remember { mutableStateOf(false) }
    var booting by remember { mutableStateOf(!BootState.done) }
    var welcoming by remember { mutableStateOf(!BootState.done) }

    LaunchedEffect(resumeTick) {
        apps = withContext(Dispatchers.IO) { AppRepository.load(ctx) }
    }
    LaunchedEffect(homeTick) {
        drawer = false
        query = ""
    }

    BackHandler(enabled = drawer) {
        if (query.isNotEmpty()) query = "" else drawer = false
    }

    CompositionLocalProvider(LocalContentColor provides Neon.Text) {
        Box(Modifier.fillMaxSize().techBackground()) {
            HomeScreen(onOpenDrawer = { drawer = true })

            AnimatedVisibility(
                visible = drawer,
                enter = slideInVertically(animationSpec = tween(220)) { it } + fadeIn(animationSpec = tween(220)),
                exit = slideOutVertically(animationSpec = tween(180)) { it } + fadeOut(animationSpec = tween(180)),
            ) {
                AppDrawer(
                    apps = apps,
                    query = query,
                    onQuery = { query = it },
                    onClose = {
                        drawer = false
                        query = ""
                    },
                )
            }

            if (booting) {
                if (welcoming) {
                    // 1º: "BEM-VINDO, NOME. ESTOU INICIANDO O SISTEMA..." (pede o nome na 1ª vez).
                    WelcomeScreen(onFinished = { welcoming = false })
                } else {
                    // 2º: abertura "SISTEMA OPERACIONAL VLM" com a barra de progresso.
                    BootScreen(onFinished = {
                        BootState.done = true
                        booting = false
                    })
                }
            }
        }
    }
}
