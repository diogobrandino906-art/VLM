package com.vlmos.launcher.ui

import android.content.Intent
import android.provider.Settings
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectVerticalDragGestures
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay
import java.time.LocalDateTime
import java.time.format.DateTimeFormatter
import java.util.Locale

/** Tela inicial: relógio grande no centro. Deslize para cima (ou toque no rodapé) para abrir os apps. */
@Composable
fun HomeScreen(onOpenDrawer: () -> Unit) {
    val ctx = LocalContext.current
    var menu by remember { mutableStateOf(false) }
    var now by remember { mutableStateOf(LocalDateTime.now()) }
    var drag by remember { mutableFloatStateOf(0f) }

    // Atualiza exatamente na virada de cada minuto.
    LaunchedEffect(Unit) {
        while (true) {
            now = LocalDateTime.now()
            delay(60_000L - (System.currentTimeMillis() % 60_000L) + 50L)
        }
    }

    Box(
        Modifier
            .fillMaxSize()
            .pointerInput(Unit) {
                detectVerticalDragGestures(
                    onDragStart = { drag = 0f },
                    onDragCancel = { drag = 0f },
                    onDragEnd = { if (drag < -100f) onOpenDrawer() },
                    onVerticalDrag = { _, dy -> drag += dy },
                )
            },
    ) {
        // Menu discreto no canto superior direito.
        Box(Modifier.align(Alignment.TopEnd).statusBarsPadding().padding(8.dp)) {
            TextButton(onClick = { menu = true }) {
                Text("⋮", color = Neon.Dim, fontSize = 20.sp)
            }
            DropdownMenu(expanded = menu, onDismissRequest = { menu = false }) {
                DropdownMenuItem(
                    text = { Text("Definir como tela inicial") },
                    onClick = {
                        menu = false
                        ctx.startActivity(Intent(Settings.ACTION_HOME_SETTINGS))
                    },
                )
                DropdownMenuItem(
                    text = { Text("Configurações do sistema") },
                    onClick = {
                        menu = false
                        ctx.startActivity(Intent(Settings.ACTION_SETTINGS))
                    },
                )
            }
        }

        // Centro: rótulo, relógio e data.
        Column(
            Modifier.align(Alignment.Center),
            horizontalAlignment = Alignment.CenterHorizontally,
        ) {
            Text(
                "SISTEMA OPERACIONAL VLM",
                fontFamily = Mono,
                fontSize = 11.sp,
                letterSpacing = 3.sp,
                color = Neon.Cyan.copy(alpha = 0.8f),
            )
            Spacer(Modifier.height(6.dp))
            Text(
                now.format(DateTimeFormatter.ofPattern("HH:mm")),
                fontFamily = Mono,
                fontSize = 92.sp,
                fontWeight = FontWeight.Light,
                color = Neon.Text,
                style = TextStyle(shadow = glow(Neon.Cyan)),
            )
            Text(
                now.format(DateTimeFormatter.ofPattern("EEE · d MMM yyyy", Locale.forLanguageTag("pt-BR")))
                    .uppercase(Locale.ROOT)
                    .replace(".", ""),
                fontFamily = Mono,
                fontSize = 14.sp,
                letterSpacing = 2.sp,
                color = Neon.Dim,
            )
            Box(
                Modifier
                    .padding(top = 18.dp)
                    .width(140.dp)
                    .height(2.dp)
                    .background(
                        Brush.horizontalGradient(listOf(Color.Transparent, Neon.Cyan, Color.Transparent)),
                    ),
            )
        }

        // Rodapé: convite para abrir a gaveta.
        Column(
            Modifier
                .align(Alignment.BottomCenter)
                .navigationBarsPadding()
                .clickable(onClick = onOpenDrawer)
                .padding(horizontal = 32.dp, vertical = 20.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
        ) {
            Text("▲", color = Neon.Cyan, fontSize = 16.sp, style = TextStyle(shadow = glow(Neon.Cyan, 16f)))
            Text(
                "DESLIZE PARA CIMA · APPS",
                fontFamily = Mono,
                fontSize = 11.sp,
                letterSpacing = 2.sp,
                color = Neon.Dim,
            )
        }
    }
}
