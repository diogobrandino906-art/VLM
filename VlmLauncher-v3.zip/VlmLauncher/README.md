# VLM OS: Launcher

Launcher Android futurista: abertura "SISTEMA OPERACIONAL VLM", relógio grande no centro e gaveta de apps que sobe ao deslizar. Sem internet, sem chaves de API, sem serviços em segundo plano.

## Recursos

- **Abertura:** o título é "digitado" com brilho neon quando o launcher inicia. Toque para pular. Só roda uma vez por inicialização do processo, não a cada toque no Home.
- **Tela inicial:** relógio e data grandes no centro, fundo escuro com grade e halo ciano.
- **Gaveta de apps:** deslize para cima (ou toque no rodapé). Grade de 4 colunas e busca; **Enter** abre o primeiro resultado. Feche arrastando a alça para baixo, com Voltar ou com Home.
- Segurar um app abre as informações dele (desinstalar, limpar dados).
- Menu ⋮ (canto superior direito): definir como tela inicial e abrir as configurações do sistema.
- Permissões: apenas `QUERY_ALL_PACKAGES` (para listar os apps). Não pede internet.

## Como compilar e instalar

1. Instale o **Android Studio** e abra a pasta `VlmLauncher`. Ele baixa o Gradle e o SDK 35 sozinho.
2. Conecte o celular (Android 8.0+ com depuração USB) e rode o app (▶).
3. Aperte Home e escolha **VLM OS** como tela inicial (ou use ⋮ > Definir como tela inicial).

Para voltar ao launcher antigo: *Configurações > Apps > Apps padrão > Tela inicial*.

## Estrutura

- `MainActivity.kt`: atividade HOME.
- `AppRepository.kt`: lista (com cache), abre e mostra info dos apps.
- `ui/Theme.kt`: cores neon, brilho, fundo com grade.
- `ui/BootScreen.kt`: abertura.
- `ui/HomeScreen.kt`: relógio e gesto de deslizar.
- `ui/AppDrawer.kt`: gaveta de apps.
- `ui/LauncherScreen.kt`: junta as camadas.

## Personalizar

- Texto da abertura: `BOOT_TITLE` em `BootScreen.kt` (e o rótulo em `HomeScreen.kt`).
- Cores: objeto `Neon` em `Theme.kt`.

## Observação

O projeto foi escrito sem compilar neste ambiente (sem Android SDK). O build pode pedir pequenos ajustes.
