package com.vlmos.launcher.ui

import android.content.Context
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardCapitalization
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay
import java.util.Locale

/** Guarda o nome da pessoa no aparelho (só local, sem internet). */
object UserPrefs {
    private const val FILE = "vlmos_prefs"
    private const val KEY_NAME = "user_name"

    fun getName(ctx: Context): String? =
        ctx.getSharedPreferences(FILE, Context.MODE_PRIVATE)
            .getString(KEY_NAME, null)
            ?.takeIf { it.isNotBlank() }

    fun setName(ctx: Context, name: String) {
        ctx.getSharedPreferences(FILE, Context.MODE_PRIVATE)
            .edit()
            .putString(KEY_NAME, name.trim())
            .apply()
    }
}

/**
 * Entrada do sistema. Na primeira vez pergunta o nome; depois mostra
 * "BEM-VINDO, NOME." / "ESTOU INICIANDO O SISTEMA..." digitado com brilho neon
 * (e falado em voz alta, se [speak]). Toque para pular. Ao fim chama [onFinished].
 */
@Composable
fun WelcomeScreen(onFinished: () -> Unit, speak: Boolean = true) {
    val ctx = LocalContext.current
    var name by remember { mutableStateOf(UserPrefs.getName(ctx)) }

    Box(
        Modifier
            .fillMaxSize()
            .techBackground()
            .imePadding(),
        contentAlignment = Alignment.Center,
    ) {
        val current = name
        if (current == null) {
            NamePrompt { typed ->
                UserPrefs.setName(ctx, typed)
                name = typed.trim()
            }
        } else {
            WelcomeMessage(current, speak, onFinished)
        }
    }
}

@Composable
private fun NamePrompt(onConfirm: (String) -> Unit) {
    var text by remember { mutableStateOf("") }
    val canConfirm = text.isNotBlank()
    val inputStyle = TextStyle(
        fontFamily = Mono,
        fontSize = 20.sp,
        letterSpacing = 1.sp,
        fontWeight = FontWeight.Bold,
        color = Neon.Text,
    )

    Column(Modifier.padding(horizontal = 32.dp)) {
        Text(
            "IDENTIFICAÇÃO",
            fontFamily = Mono,
            fontSize = 11.sp,
            letterSpacing = 3.sp,
            color = Neon.Dim,
        )
        Spacer(Modifier.height(10.dp))
        Text(
            "QUAL É O SEU NOME?",
            style = TextStyle(
                fontFamily = Mono,
                fontSize = 20.sp,
                letterSpacing = 1.sp,
                fontWeight = FontWeight.Bold,
                shadow = glow(Neon.Cyan),
            ),
            color = Neon.Cyan,
        )
        Spacer(Modifier.height(20.dp))
        BasicTextField(
            value = text,
            onValueChange = { text = it.take(24) },
            singleLine = true,
            textStyle = inputStyle,
            cursorBrush = SolidColor(Neon.Cyan),
            keyboardOptions = KeyboardOptions(
                capitalization = KeyboardCapitalization.Words,
                imeAction = ImeAction.Done,
            ),
            keyboardActions = KeyboardActions(onDone = { if (canConfirm) onConfirm(text) }),
            modifier = Modifier
                .fillMaxWidth()
                .border(1.dp, Neon.Cyan.copy(alpha = 0.6f))
                .padding(horizontal = 16.dp, vertical = 14.dp),
        )
        Spacer(Modifier.height(20.dp))
        Text(
            "[ CONFIRMAR ]",
            fontFamily = Mono,
            fontSize = 16.sp,
            fontWeight = FontWeight.Bold,
            letterSpacing = 2.sp,
            color = Neon.Cyan,
            modifier = Modifier
                .alpha(if (canConfirm) 1f else 0.35f)
                .clickable(enabled = canConfirm) { onConfirm(text) }
                .padding(vertical = 10.dp),
        )
    }
}

@Composable
private fun WelcomeMessage(name: String, speak: Boolean, onFinished: () -> Unit) {
    val ctx = LocalContext.current
    val line1 = "BEM-VINDO, ${name.uppercase(Locale.getDefault())}."
    val line2 = "ESTOU INICIANDO O SISTEMA..."
    val full = "$line1\n$line2"

    var shown by remember { mutableIntStateOf(0) }
    var cursorOn by remember { mutableStateOf(true) }

    // 1) Som de abertura. Só depois dele começam o texto e a voz.
    var soundDone by remember { mutableStateOf(false) }
    DisposableEffect(Unit) {
        val track = BootSound.start()
        onDispose {
            track?.stop()
            track?.release()
        }
    }
    LaunchedEffect(Unit) {
        delay(BootSound.DURATION_MS + 100)
        soundDone = true
    }

    // 2) Voz opcional. Fica true quando a voz terminou (ou falhou / não está ligada).
    var speechDone by remember { mutableStateOf(!speak) }
    var engine by remember { mutableStateOf<TextToSpeech?>(null) }

    DisposableEffect(name, speak) {
        var created: TextToSpeech? = null
        if (speak) {
            created = TextToSpeech(ctx) { status ->
                val e = created
                if (status == TextToSpeech.SUCCESS && e != null) {
                    e.language = Locale("pt", "BR")
                    e.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                        override fun onStart(utteranceId: String?) {}
                        override fun onDone(utteranceId: String?) { speechDone = true }
                        @Deprecated("Deprecated in Java")
                        override fun onError(utteranceId: String?) { speechDone = true }
                    })
                    engine = e
                } else {
                    speechDone = true
                }
            }
        }
        onDispose {
            created?.stop()
            created?.shutdown()
        }
    }

    // Fala assim que o som terminou e o motor de voz está pronto (o que vier por último).
    LaunchedEffect(engine, soundDone) {
        val e = engine
        if (e != null && soundDone) {
            val result = e.speak(
                "Bem-vindo, $name. Estou iniciando o sistema.",
                TextToSpeech.QUEUE_FLUSH,
                null,
                "vlmos_welcome",
            )
            if (result != TextToSpeech.SUCCESS) speechDone = true
        }
    }

    // 3) Digita o texto (depois do som), espera a voz terminar (máx. 10 s) e segue.
    LaunchedEffect(full, soundDone) {
        if (soundDone) {
            for (i in 1..full.length) {
                shown = i
                delay(50)
            }
            var waited = 0L
            while (!speechDone && waited < 10_000L) {
                delay(100)
                waited += 100
            }
            delay(600)
            onFinished()
        }
    }
    LaunchedEffect(Unit) {
        while (true) {
            delay(350)
            cursorOn = !cursorOn
        }
    }

    val style = TextStyle(
        fontFamily = Mono,
        fontSize = 20.sp,
        lineHeight = 30.sp,
        letterSpacing = 1.sp,
        fontWeight = FontWeight.Bold,
    )

    Box(
        Modifier
            .fillMaxSize()
            .clickable(interactionSource = remember { MutableInteractionSource() }, indication = null) {
                onFinished()
            },
        contentAlignment = Alignment.Center,
    ) {
        Box(Modifier.padding(horizontal = 24.dp)) {
            // Texto invisível reserva o espaço todo, para o bloco não "pular" enquanto digita.
            Text("$full█", style = style, color = androidx.compose.ui.graphics.Color.Transparent)
            Text(
                full.take(shown) + if (cursorOn) "█" else "",
                style = style.copy(shadow = glow(Neon.Cyan)),
                color = Neon.Cyan,
            )
        }
    }
}
